    }
    ret = (len == 0);
  }
  return ret;
}

#endif /* _WIN32 */
