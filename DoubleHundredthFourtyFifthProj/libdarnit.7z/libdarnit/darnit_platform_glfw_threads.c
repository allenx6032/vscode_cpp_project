#ifdef _WIN32
#include "darnit_platform_threads_w32.c.inc"
#endif
