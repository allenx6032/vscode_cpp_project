#ifndef __PLATFORM_GLFW_SOUND_H__
#define	__PLATFORM_GLFW_SOUND_H__

#ifdef _WIN32
#include "darnit_platform_sound_w32.inc.h"
#endif


#endif
