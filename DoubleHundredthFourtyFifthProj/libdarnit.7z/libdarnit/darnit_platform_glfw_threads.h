#ifndef __PLATFORM_THREADS_H__
#define	__PLATFORM_THREADS_H__

#ifdef _WIN32
#include "darnit_platform_threads_w32.h.inc"
#endif

#endif
