/*
    This file is a part of yoyoengine. (https://github.com/yoyoengine/yoyoengine)
    Copyright (C) 2023-2025  Ryan Zmuda

    Licensed under the MIT license. See LICENSE file in the project root for details.
*/

/**
    @file yoyoengine.h
    @brief The master header for yoyoengine. Includes all other headers.
*/

#ifndef YE_ENGINE_MAIN_H
#define YE_ENGINE_MAIN_H
#define NK_INCLUDE_FIXED_TYPES

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

#include <yoyo_export.h>

/*
    Include all our headers in one place.
    This lets the game use
    #include <yoyoengine.h> assuming they have
    defined the header and lib paths correctly.
*/
#include "yoyo_version.h"        // version info
#include "yoyo_engine.h"         // init and core
#include "yoyo_config.h"         // jansson wrapper for config files
#include "yoyo_networking.h"
#include "yoyo_event.h"          // event handling
#include "yoyo_input.h"
#include "yoyo_yep.h"            // custom binary format parser/packer
#include "yoyo_json.h"           // jansson wrapper
#include "yoyo_graphics.h"
#include "yoyo_debug_renderer.h"
#include "uthash.h"
#include "yoyo_cache.h"
#include "yoyo_physics.h"

// ui //
#include "yoyo_ui.h"
#include "yoyo_overlays.h"

// overlays //
#include "yoyo_physics_overlay.h"

// ecs //
#include "yoyo_ecs.h"
#include "yoyo_button.h"
#include "yoyo_audiosource.h"
#include "yoyo_camera.h"
#include "yoyo_renderer.h"
#include "yoyo_rigidbody.h"
#include "yoyo_transform.h"
#include "yoyo_tag.h"
#include "lua_script.h"

#include "yoyo_utils.h"
#include "yoyo_timer.h"
#include "yoyo_audio.h"
#include "yoyo_logging.h"        // logging
#include "lua_api.h"        // scripting api
#include "yoyo_scene.h"          // scene manager
#include "yoyo_tricks.h"         // plugin system

#endif // YE_ENGINE_MAIN_H