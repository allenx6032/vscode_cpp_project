/*
    This file is a part of yoyoengine. (https://github.com/yoyoengine/yoyoengine)
    Copyright (C) 2023-2025  Ryan Zmuda

    Licensed under the MIT license. See LICENSE file in the project root for details.
*/

/**
    @file engine.h
    @brief The header for the engine entry point, contains state definitions.
*/

#ifndef ENGINE_H
#define ENGINE_H

#include <p2d.h>

#include <yoyo_export.h>

#include <Lilith.h>

#include <stdbool.h>

#include <SDL.h>
#include <SDL_ttf.h>

#include "yoyo_graphics.h"
#include "yoyo_ecs.h"

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

#ifdef YE_BUILD_MODE
    /*
        Do things like limit the debug log output unless override is set
    */
#endif


YE_API extern struct ye_engine_state YE_STATE;

/**
 * @brief A struct that defines a screen size by width and height.
 */
struct ScreenSize {
    int width;
    int height;
};

/**
 * @brief !!!THIS IS NOT FOR USE AT RUNTIME!!! Returns a string of the full path (os specific) to the engine resource you have referenced.
 * 
 * Behaves the same as @ref ye_path_resource, but is meant for accessing engine resources.
 * 
 * @param sub_path The relative path (or just name with extension) of the engine resource you wish to access.
 * @return char* The absolute path to the engine resource.
 */
YE_API char* ye_get_engine_resource_static(const char *sub_path);

/**
 * @brief Returns a pointer to a string in engine memory that contains the absolute path relative to the executable of the item you have specified.
 * 
 * @param path The path relative to the executable you want to path to
 * @return char* A reference to the built string
 * 
 * NOTE: this only persists until the next call to this function. You must make your own copies if you need it to stick around
 */
YE_API char * ye_path(const char * path);

/**
 * @brief THIS IS NOT FOR USE WITH RUNTIME RESOURCES. This is for editor resources only.
 * 
 * @param path The path relative to the project resources folder
 * @return char* The constructed path
 */
YE_API char * ye_path_resources(const char * path);

/**
 * @brief The struct that defines the configuration of the engine core specifically.
*/
struct ye_engine_config {
    /*
        Window Properties
        Do not update in realtime, only on init OR recompute functions
    */
    int screen_width;
    int screen_height;
    int volume;
    int window_mode;
    int framecap;
    char *window_title;
    char *icon_path;
    
    /*
        Quality / Rendering Properties
    */
    int sdl_quality_hint; // 0 (_nearest_ pixel), 1 (_linear_ filtering), 2 (anisotropic filtering/_best_)

    /*
        Some fields that handle pillarboxing and letterboxing
    */
    bool stretch_resolution;    // i dont even remember what stretch viewport does anymore... editor only? || this controls whether we even want to stretch
    bool need_boxing;           // if we need to pillarbox or letterbox
    SDL_Rect letterbox;        // the letterbox rect

    /*
        0 - debug and higher
        1 - info and higher
        2 - warning and higher
        3 - error and higher
        4 - nothing
    */
    int log_level;

    /*
        Provides some internal override behavior over defaults.
        Ex: logging will print to stdout before init.
    */
    bool debug_mode;

    /*
        TODO: remove me?
    */
    bool skipintro;

    /*
        Allocated strings for resource accessing paths.
    */
    char *engine_resources_path;
    char *game_resources_path;
    char *log_file_path;

    /*
        Controls which camera the scene is rendered from the perspective of.
    */
    struct ye_entity *target_camera;

    /*
        By default, the viewport will render from its actual perspective,
        setting this to true will disable this behavior and simply paint any object in the
        cameras view cone to the viewport actual position
    */
    bool stretch_viewport;

    /*
        The font and color used for when the engine needs to render text
        but is missing a font or color from. This will be automatically freed
        at the end of the engine's lifecycle, so if you replace these manually please
        free the old pointers.
    */
    SDL_Color *pEngineFontColor;
    TTF_Font *pEngineFont;

    // the nuklear context
    struct nk_context *ctx; // TODO: should maybe be moved to runtime but idgaf rn

    // TODO: p2d state
    struct p2d_state *p2d_state;
};

/**
 * @brief The struct that defines the configuration of the editor specifically.
 */
struct ye_editor_config {
    /*
        Controls whether the engine is in "editor mode"
        This has implications for how rendering is handled and which systems are enabled.
    */
    bool editor_mode;

    /*
        A whole bunch of editor flags
        that can also be changed at runtime
        to debug or potentially for visual effect
    */
    bool paintbounds_visible;
    bool colliders_visible;
    bool display_names;
    bool freecam_enabled;
    bool audiorange_visible;
    bool button_bounds_visible;
    bool wireframe_visible;
    /*
        Only work with editor_mode enabled:
    */
    bool editor_display_viewport_lines;
    bool scene_camera_bounds_visible; // should work without editor but i dont feel like testing

    /*
        Only used in editor mode to designate the camera the scene file has marked
        as default, so when we replace the rendering camera with the editor camera
        we still know which camera the scene file has marked as default

        ex: Draw camera viewport outline
    */
    struct ye_entity *scene_default_camera;
};

#define YE_MAX_CONTROLLERS 4

/**
 * @brief The struct that defines the runtime data of the engine.
 */
struct ye_runtime_data {
    /*
        Some variables tracking things we might
        be interested in at any given time:
    */
    int entity_count;           // scene entities
    int painted_entity_count;   // scene entities actually painted (OBSOLETE? TODO)
    int fps;                    // our current fps (updated every frame)
    
    int paint_time;             // time in ms it took to paint the last frame
    int frame_time;             // overall time in ms it took to process the last frame (the delay included)
    int input_time;             // time in ms it took to process the input for the last frame
    int physics_time;           // time in ms it took to process the physics for the last frame
    float delta_time;           // the delta time in SECONDS between the last frame and the current frame
    
    int log_line_count;         // the number of lines in the log file
    int audio_chunk_count;      // the number of audio chunks currently allocated and playing
    
    char *scene_name;           // TODO: store current scene path for reloading in editor?
    char *scene_file_path;      // the path to the open scene file

    int error_count;            // tracks the number of error level logs that have occurred
    int warning_count;          // same but for warnings

    struct {
        int num_render_calls;   // number of RenderGeometry calls made this frame
        int num_verticies;      // number of verticies sent to RenderGeometry this frame
    } render_v2;

    /*
        Meta on opened controllers
    */
    SDL_GameController *controllers[YE_MAX_CONTROLLERS];
    int num_controllers;

    /*
        References to the current SDL window and renderer
    */
    SDL_Window *window;
    SDL_Renderer *renderer;

    /*
        Cache/important globals
    */
    mat3_t world2cam; // the world to camera matrix
}; // TODO: move a bunch more information here, audio capacity comes to mind. expose some stuff here just for usage.

/*
    Struct that defines the state for the entire core engine, as well as some important editor state
    that is not necessarily part of the engine, but is important to the editor injecting its
    own behavior into the core and renderer
*/
/**
 * @brief The struct that defines the state of the entire engine, editor and runtime.
 * 
 * This contains references to @ref ye_engine_config, @ref ye_runtime_data, and @ref ye_editor_config.
*/
struct ye_engine_state {
    struct ye_engine_config engine;
    struct ye_runtime_data runtime;
    struct ye_editor_config editor;
};

/**
 * @brief The master function that returns control to the engine to process the next frame.
 * 
 * Will invoke many functions to process the next frame, including:
 * - @ref ui_handle_input
 * - @ref ye_system_physics
 * - @ref ye_render_all
 * 
 * As well as many other misc operations, such as updating the current delta in @ref ye_runtime_data
 */
YE_API void ye_process_frame();

/**
 * @brief Returns the current delta time in milliseconds.
 * 
 * Will pull the current delta time from @ref ye_runtime_data.
 * This exists just for ease of use and potentially wrapping later on.
 * 
 * @return float 
 */
YE_API float ye_delta_time();

/**
 * @brief Updates the engines resources path to the new path provided.
 * 
 * The only use of this at the moment is for the editor to switch into the game its
 * trying to edit after it loads all its necessary editor specific resources.
 * 
 * @param path The (absolute) path to the new resources folder.
 */
YE_API void ye_update_base_path(const char *path);

/*
    entry point to the engine, initializes all subsystems
    Will look at ./settings.yoyo for initialization parameters (if empty or nonexistant will use defaults)
*/

/**
 * @brief The entry point to the engine, initializes all subsystems.
 * 
 * You will need to have a 'settings.yoyo' file at the root of your project to initialize the engine. 
 */
YE_API void ye_init_engine();

/**
 * @brief Shuts down the engine and all subsystems.
 * 
 * Does not shut down your own game logic, you will need a game loop to do that.
 * If you are using the editor and the default entry point, both will be handled for you.
 */
YE_API void ye_shutdown_engine();

#endif