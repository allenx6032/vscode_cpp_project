#ifndef SDL_GFX_H
#define SDL_GFX_H

#include <SDL_framerate.h>
#include <SDL_gfxBlitFunc.h>
#include <SDL_gfxPrimitives.h>
#include <SDL_gfxPrimitives_font.h>
#include <SDL_imageFilter.h>
#include <SDL_rotozoom.h>

#endif